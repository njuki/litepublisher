<?php
define('litepublisher_mode', 'xmlrpc');
include('index.php');
$s = file_get_contents('dump.sql');litepublisher::$db = new tdatabase;
$o = new tevents();
$o->basename = 'options';
$o->Load();
litepublisher::$options  = $o;
litepublisher::$db = new tdatabase ();
$man = tdbmanager::instance();
$man->import($s);
echo "imported";
