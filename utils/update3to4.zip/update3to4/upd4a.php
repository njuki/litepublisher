<?php
define('litepublisher_mode', 'xmlrpc');
require('index.php');
litepublisher::$debug = true;
//require(litepublisher::$paths->lib . 'update' . DIRECTORY_SEPARATOR  . 'update.4php');
require('update.4.13.php');
echo "<pre>\n";
echo litepublisher::$options->version, "\n";
updateto399();
litepublisher::$options->savemodified();
echo litepublisher::$options->version, "\n";
create_storage();

$r = tupdater::instance()->autoupdate();
var_dump($r);
create_storage_folder();
