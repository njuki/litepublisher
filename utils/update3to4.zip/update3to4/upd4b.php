<?php
define('litepublisher_mode', 'xmlrpc');
require('index.php');
litepublisher::$debug = true;
//require(litepublisher::$paths->lib . 'update' . DIRECTORY_SEPARATOR  . 'update.4php');
require('update.4.00.php');
set_time_limit(400);
echo "<pre>\n";
echo litepublisher::$options->version, "\n";
update_step2();
litepublisher::$options->version = '4.01';
litepublisher::$options->savemodified();

echo "updated";
